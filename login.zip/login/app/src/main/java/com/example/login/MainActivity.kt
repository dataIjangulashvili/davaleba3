package com.example.login

import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi


class MainActivity : AppCompatActivity() {
    lateinit var username: TextView


    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val signin = findViewById<TextView>(R.id.signin)
        val gmail = findViewById<EditText>(R.id.gmail)
        val password = findViewById<EditText>(R.id.password)
        val button = findViewById<TextView>(R.id.button)

        findViewById<Button>(R.id.button).setOnClickListener {
            var gmail = gmail.text.toString()
            var password = password.text.toString()

            if (gmail == null)
                Toast.makeText(this, "Please enter your gmail adress", Toast.LENGTH_SHORT).show()
            else if (password == null)
                Toast.makeText(this, "Please enter your password", Toast.LENGTH_SHORT).show()
            else {
                signin.setTextColor(getColor(R.color.black))

                
            }
        }
    }
}